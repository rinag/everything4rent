from .models import *
from django.contrib.auth import login
from django.contrib.auth.models import User
from django.contrib.sites.shortcuts import get_current_site
from django.shortcuts import render
from django.utils.encoding import force_bytes, force_text
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.shortcuts import get_object_or_404
from .forms import SignUpForm, AddForm, BuyForm, AdvancedSearchForm
from .forms import ContactForm
from .tokens import account_activation_token
from django.core.mail import EmailMessage
from django.shortcuts import redirect
from django.template.loader import render_to_string
import random

def update_all_model():
    list_of_model = {'all_product': Product.objects.all(), 'all_year': Category.objects.all()}
    return list_of_model

def get_client_ip(request):
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip

def vehicles(request):
    category = get_object_or_404(Category, category='רכב')
    products = category.product_set.all()
    list_of_model = update_all_model()
    list_of_model.update({'sort_all_product': products})
    return render(request, 'catalog/vehicles.html', list_of_model)

def packageDeal(request):
    category = get_object_or_404(Category, category='עסקת חבילה')
    products = category.product_set.all()
    list_of_model = update_all_model()
    list_of_model.update({'sort_all_product': products})
    return render(request, 'catalog/packageDeal.html', list_of_model)

def animals(request):
    category = get_object_or_404(Category, category='חיות מחמד')
    products = category.product_set.all()
    list_of_model = update_all_model()
    list_of_model.update({'sort_all_product': products})
    return render(request, 'catalog/animals.html', list_of_model)

def realestate(request):
    category = get_object_or_404(Category, category='נדל״ן')
    products = category.product_set.all()
    list_of_model = update_all_model()
    list_of_model.update({'sort_all_product': products})
    return render(request, 'catalog/realestate.html', list_of_model)

def secondhand(request):
    category = get_object_or_404(Category, category='יד שניה')
    products = category.product_set.all()
    list_of_model = update_all_model()
    list_of_model.update({'sort_all_product': products})
    return render(request, 'catalog/secondhand.html', list_of_model)

def about(request):
    list_of_model = update_all_model()
    return render(request, 'catalog/about.html', list_of_model)

def product_page(request, product_id):

    product = get_object_or_404(Product, pk=product_id)
    if request.method == 'POST':
        form = BuyForm(request.POST)
        if form.is_valid():
            if request.user.is_authenticated:
                subject = request.POST.get('subject', '')
                phone_number = request.POST.get('phone_number', '')
                form_content = request.POST.get('content', '')
                offer = request.POST.get('offer', '')

                f = Offer.objects.create(
                    item_owner=product.user_id,
                    item_buyer = request.user.id,
                    offer = offer,
                    item_number = product.pk
                )
                f.save()
                # Email the profile with the
                # contact information
                context = {
                    'contact_name': request.user.username,
                    'contact_email': request.user.email,
                    'phone_number': phone_number,
                    'form_content': form_content,
                    'offer': offer
                }

                message = render_to_string('catalog/offer_template.txt', context)
                user = get_object_or_404(User, pk=product.user_id)
                email = EmailMessage(
                    subject,
                    message,
                    to=[user.email],
                    headers={'Reply-To': request.user.email}
                )
                email.send()
                return redirect('../offer_sent_successfully')

    product.rank += 1
    product.save()

    formBuyForm = BuyForm(initial={'subject': product.name})
    list_of_model = update_all_model()
    list_of_model.update({'product': product, 'formBuyForm': formBuyForm})
    return render(request, 'catalog/product_page.html', list_of_model)

def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)

        if form.is_valid():
            user = form.save(commit=False)
            user.email = request.POST.get('email1', '')
            user.is_active = False
            user.save()

            profile = get_object_or_404(Profile, user=user)
            profile.city = request.POST.get('city', '')
            #####
            profile.save()

            current_site = get_current_site(request)
            subject = 'Activate Your Everything4Rent Account'
            message = render_to_string('catalog/account_activation_email.html', {
                'user': user,
                'domain': current_site.domain,
                'uid': user.pk,
                'token': account_activation_token.make_token(user),
            })

            email = EmailMessage(
                subject,
                message,
                to=[user.email],
                headers={'Reply-To': 'everything4rentyad2@gmail.com'}
            )
            email.send()
            return redirect('../../account_activation_sent')

    else:
        form = SignUpForm()
    list_of_model = update_all_model()
    list_of_model.update({'form': form})
    return render(request, 'catalog/signup.html', list_of_model)

def home(request):
    list_of_model = update_all_model()
    all_data_ele = []
    all_data = HomePage.objects.all()
    range_list = []
    for i in range(len(all_data)):
        all_data_ele.append([i,all_data[i]])
        range_list.append(i)
    video_list =  VideoHomePage.objects.all()
    random_number = random.randint(0, len(video_list) - 1)
    list_of_model.update({'all_data': all_data_ele, 'range': range_list, 'video': video_list[random_number]})
    return render(request, 'catalog/home.html', list_of_model)

def contact(request):
    form_class = ContactForm
    if request.method == 'POST':
        form = form_class(data=request.POST)
        if form.is_valid():
            subject = request.POST.get('subject', '')
            contact_name = request.POST.get('contact_name', '')
            contact_email = request.POST.get('contact_email', '')
            phone_number = request.POST.get('phone_number', '')
            form_content = request.POST.get('content', '')

            # Email the profile with the contact information:
            context = {
                'contact_name': contact_name,
                'contact_email': contact_email,
                'phone_number': phone_number,
                'form_content': form_content
            }

            message = render_to_string('catalog/contact_template.txt', context)
            email = EmailMessage(
                subject,
                message,
                to=['everything4rentyad2@gmail.com'],
                headers = {'Reply-To': contact_email}
            )
            email.send()
            return redirect('../msg_send_successfully')

    list_of_model = update_all_model()
    list_of_model.update({'form': form_class, 'authorized_agent': AuthorizedAgent.objects.all()})
    return render(request, 'catalog/contact.html', list_of_model)

def add(request):
    form_class = AddForm
    if request.method == 'POST':
        if request.user.is_authenticated:
            form = form_class(data=request.POST)
            product_name = request.POST.get('product_name', '')
            sell_method = request.POST.get('sell_method', '')
            category = request.POST.get('category', '')
            price = request.POST.get('price', '')
            product_image = request.POST.get('product_image', '')
            content = request.POST.get('content', '')
            sell_method_ojb = get_object_or_404(SellMethod, sell_method=sell_method)
            category = get_object_or_404(Category, category=category)

            product = Product.objects.create(
                sell_method = sell_method_ojb,
                category = category,
                price = price,
                name = product_name,
                img_url = product_image,
                text = content,
                user_id = request.user.pk
            )
            product.save()
            return redirect('../product_added_successfully.html')

    list_of_model = update_all_model()
    list_of_model.update({'form': form_class, 'authorized_agent': AuthorizedAgent.objects.all()})
    return render(request, 'catalog/add.html', list_of_model)

def account_activation_sent(request):
    list_of_model = update_all_model()
    return render(request, 'catalog/account_activation_sent.html', list_of_model)

def activate(request, uidb64, token):
    try:
        uid = uidb64
        user = get_object_or_404(User.objects, pk=uid)
    except (TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None

    if user is not None and account_activation_token.check_token(user, token):
        user.is_active = True
        user.profile.email_confirmed = True
        user.save()
        login(request, user)
        return redirect('/../../../../')
    else:
        list_of_model = update_all_model()
        return render(request, 'catalog/account_activation_invalid.html', list_of_model)

def catalog_by_year_type(request, year, type):
    year_by_id = get_object_or_404(Category, pk=year)
    type = get_object_or_404(year_by_id.type_set, pk=type)
    series_all = type.series_set.all()
    list_of_model = update_all_model()
    list_of_model.update({'series_all': series_all, 'type': type.type})
    return render(request, 'catalog/catalog.html', list_of_model)

class ProfileObj:
    product = 0
    offer = 0;
    user = 0
    def __init__(self, product, offer, user):
        self.product = product
        self.offer = offer
        self.user = user

def profile(request):
    list_of_model = update_all_model()

    if request.user.is_authenticated:
        profile = get_object_or_404(Profile, user=request.user)
        all_product = Product.objects.all()
        results = []
        for product in all_product:
            if str(product.user_id) == str(request.user.pk):
                results.append(product)

        all_offers = Offer.objects.all()
        offers_received = []
        for offer in all_offers:

            if str(offer.item_buyer) == str(request.user.pk):
                p = ProfileObj(
                    product=get_object_or_404(Product, pk=offer.item_number),
                    offer=offer,
                    user = get_object_or_404(User, pk=offer.item_buyer)
                )
                offers_received.append(p)

        if request.user.is_authenticated:
            all_offers = Offer.objects.all()
            offers_made = []
            for offer in all_offers:
                if str(offer.item_owner) == str(request.user.pk):
                    p = ProfileObj(
                        product=get_object_or_404(Product, pk=offer.item_number),
                        offer=offer,
                        user=get_object_or_404(User, pk=offer.item_owner)
                    )
                    offers_made.append(p)

        list_of_model.update({'profile': profile, 'results': results, 'offers_received': offers_received, 'offers_made': offers_made})

    return render(request, 'catalog/profile.html', list_of_model)

def cart(request):
    list_of_model = update_all_model()
    return render(request, 'catalog/cart.html', list_of_model)

def msg_send_successfully(request):
    list_of_model = update_all_model()
    return render(request, 'catalog/msg_send_successfully.html', list_of_model)

def offer_sent_successfully(request):
    list_of_model = update_all_model()
    return render(request, 'catalog/offer_sent_successfully.html', list_of_model)

def product_added_successfully(request):
    list_of_model = update_all_model()
    return render(request, 'catalog/product_added_successfully.html', list_of_model)

def search(request):
    if request.method == 'GET':
        search_text = request.GET.get('q', '')

    all_product = Product.objects.all()
    results = []
    for product in all_product:
        if search_text.lower() in product.text.lower() or search_text.lower() in product.name.lower():
            results.append(product)

    list_of_model = update_all_model()
    list_of_model.update({'results': results})
    return render(request, 'catalog/results.html', list_of_model)

def advancedSearch(request):
    form_class = AdvancedSearchForm

    if request.method == 'POST':
        search_text = request.POST.get('free_search', '')
        category = request.POST.get('category', '')
        sell_method = request.POST.get('sell_method', '')

        all_product = Product.objects.all()
        results = []
        for product in all_product:
            if search_text.lower() in product.text.lower() or search_text.lower() in product.name.lower():
                if str(category) == str(product.category):
                    if str(sell_method) == str(product.sell_method):
                        results.append(product)

        list_of_model = update_all_model()
        list_of_model.update({'results': results})
        return render(request, 'catalog/results.html', list_of_model)

    list_of_model = update_all_model()
    list_of_model.update({'form': form_class})
    return render(request, 'catalog/advancedSearch.html', list_of_model)
