from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver

class Category(models.Model):
    category = models.CharField(max_length=250)
    def __str__(self):
       return self.category

class SellMethod(models.Model):
    sell_method = models.CharField(max_length=250)
    def __str__(self):
       return self.sell_method

class SubCategory(models.Model):
    sub_category = models.CharField(max_length=250)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    def __str__(self):
       return self.category.__str__() + " - " + self.sub_category

class Product(models.Model):
    sell_method = models.ForeignKey(SellMethod, on_delete=models.CASCADE)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    price = models.CharField(max_length=250)
    name = models.CharField(max_length=250, blank=True)
    rank = models.IntegerField(default=0,  blank=True)
    img_url = models.CharField(max_length=1000, blank=True)
    text = models.CharField(max_length=5000, blank=True)
    pic = models.ImageField(upload_to='pic_folder', blank=True)
    user_id = models.CharField(max_length=250)

    def __str__(self):
       return self.name

class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    city = models.CharField(max_length=30, blank=True)
    email_confirmed = models.BooleanField(default=False)

class AuthorizedAgent(models.Model):
    name = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    phone_number = models.CharField(max_length=100)

    def __str__(self):
       return self.name

class HomePage(models.Model):
    title = models.CharField(max_length=100, blank=True)
    text = models.TextField(max_length=5000, blank=True)
    url = models.CharField(max_length=1000, blank=True)

    def __str__(self):
       return self.title

class VideoHomePage(models.Model):
    youtube_url = models.CharField(max_length=500, blank=True)
    def __str__(self):
       return self.youtube_url

@receiver(post_save, sender=User)
def update_user_profile(sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(user=instance)
        instance.profile.save()

class Image(models.Model):
    image = models.ImageField()
    gory = models.BooleanField()

class Offer(models.Model):
    item_owner = models.CharField(max_length=250, blank=True)
    item_buyer = models.CharField(max_length=250, blank=True)
    offer = models.CharField(max_length=250, blank=True)
    item_number = models.CharField(max_length=250, blank=True)

    def __str__(self):
       return self.offer
