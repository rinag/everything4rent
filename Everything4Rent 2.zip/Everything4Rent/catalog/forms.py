from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from catalog.templates.catalog.choices import CATEGORY_CHOICES, SELLINGMETHOD_CHOICES

class SignUpForm(UserCreationForm):
    username = forms.CharField(max_length=254,
                                widget=forms.TextInput(
                                    attrs={'type': 'username', 'class': 'form-control input-sm chat-input'}),
                                label="שם משתמש",
                               help_text="שם משתמש באנגלית")

    email1 = forms.EmailField(max_length=254,
                             label="דואר אלקטרוני",
                             help_text='ידרש אימות של המייל',
                             widget=forms.TextInput(
                             attrs={'type': 'email', 'class': 'form-control input-sm chat-input'}))

    password1 = forms.CharField(max_length=254,
                             label="סיסמה",
                             widget = forms.TextInput(attrs={'type': 'password', 'class': 'form-control input-sm chat-input'}),
                             help_text="לפחות 8 תווים, על הסיסמה להיות מורכבת מאותיות ומספרים")

    password2 = forms.CharField(max_length=254,
                                widget=forms.TextInput(attrs={'type': 'password', 'class': 'form-control input-sm chat-input'}),
                                label="אימות סיסמה")

    city = forms.CharField(max_length=254,
                               label="עיר",
                               widget=forms.TextInput(attrs={'type': 'text', 'class': 'form-control input-sm chat-input'}))

    class Meta:
        model = User
        fields = ('username', 'email1', 'password1', 'password2', 'city')

class ContactForm(forms.Form):
    contact_name = forms.CharField(required=True,
                                   label = "שם מלא",
                                   widget = forms.TextInput(attrs={'type': 'text', 'class': 'form-control input-sm chat-input'}))

    contact_email = forms.EmailField(required=True,
                                   label = "דואר אלקטרוני",
                                   widget = forms.TextInput(attrs={'type': 'email', 'class': 'form-control input-sm chat-input'}))

    subject = forms.CharField(required=True,
                                   label = "נושא",
                                   widget = forms.TextInput(attrs={'type': 'text', 'class': 'form-control input-sm chat-input'}))

    phone_number = forms.CharField(required=True,
                              label="טלפון",
                              widget=forms.TextInput(
                                  attrs={'type': 'text', 'class': 'form-control input-sm chat-input'}))

    content = forms.CharField(
        label="גוף ההודעה",
        required=True,
        widget=forms.Textarea(attrs={'rows': 5, 'cols': 100, 'type': 'text', 'class': 'form-control input-sm chat-input', 'text-align': 'right'}))


class BuyForm(forms.Form):
    subject = forms.CharField(required=True,
                                   label = "נושא",
                                   widget = forms.TextInput(attrs={'type': 'text', 'class': 'form-control input-sm chat-input'}))

    phone_number = forms.CharField(required=True,
                              label="טלפון",
                              widget=forms.TextInput(
                                  attrs={'type': 'text', 'class': 'form-control input-sm chat-input'}))

    offer = forms.CharField(required=True,
                              label="הצעת מחיר",
                              widget=forms.TextInput(
                                  attrs={'type': 'text', 'class': 'form-control input-sm chat-input'}))

    content = forms.CharField(
        label="הודעה",
        required=True,
        widget=forms.Textarea(attrs={'rows': 5, 'cols': 100, 'type': 'text', 'class': 'form-control input-sm chat-input', 'text-align': 'right'}))

class AddForm(forms.Form):
    category = forms.ChoiceField(choices=CATEGORY_CHOICES, required=True, label="קטגוריה")

    sell_method = forms.ChoiceField(choices=SELLINGMETHOD_CHOICES, required=True, label="פרסום למטרת")

    price = forms.CharField(required=True,
                                   label = "מחיר",
                                   widget = forms.TextInput(attrs={'type': 'price', 'class': 'form-control input-sm chat-input'}))

    product_name = forms.CharField(required=True,
                              label="שם פריט",
                              widget=forms.TextInput(
                                  attrs={'type': 'text', 'class': 'form-control input-sm chat-input'}))

    phone_number = forms.CharField(required=True,
                              label="טלפון",
                              widget=forms.TextInput(
                                  attrs={'type': 'text', 'class': 'form-control input-sm chat-input'}))

    product_image = forms.URLField(label="הוסף תמונה")

    content = forms.CharField(
        label="תיאור פריט",
        required=True,
        widget=forms.Textarea(attrs={'rows': 5, 'cols': 100, 'type': 'text', 'class': 'form-control input-sm chat-input', 'text-align': 'right'}))


class AdvancedSearchForm(forms.Form):
    free_search = forms.CharField(required=False,
                              label="טקסט חופשי",
                              widget=forms.TextInput(
                                  attrs={'type': 'text', 'class': 'form-control input-sm chat-input'}))

    category = forms.ChoiceField(choices=CATEGORY_CHOICES, required=True, label="קטגוריה")

    sell_method = forms.ChoiceField(choices=SELLINGMETHOD_CHOICES, required=True, label="פריט ל")
