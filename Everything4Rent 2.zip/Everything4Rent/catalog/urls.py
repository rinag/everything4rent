from django.conf.urls import url
from django.contrib.auth import views as auth_views
from catalog.models import Category
from . import views as core_views

app_name = 'catalog'
MEDIA_URL = '/media/'
urlpatterns = [
    url(r'^$', core_views.home, name='home'),
    url(r'^vehicles', core_views.vehicles, name='vehicles'),
    url(r'^(?P<product_id>[0-9]+)/$', core_views.product_page, name='product_page'),
    url(r'^login/$', auth_views.login, {'template_name': 'catalog/home.html' , 'extra_context':{'all_year': Category.objects.all()}}, name='login'),
    url(r'^logout/$', auth_views.logout, {'next_page': '/successfully_logged_out/', 'extra_context':{'all_year': Category.objects.all()}}, name='logout'),
    url(r'^profile/$', core_views.profile, name='profile'),
    url(r'^signup/$', core_views.signup, name='signup'),
    url(r'^contact/$', core_views.contact, name='contact'),
    url(r'^add/$', core_views.add, name='add'),
    url(r'^secondhand/$', core_views.secondhand, name='secondhand'),
    url(r'^animals/$', core_views.animals, name='animals'),
    url(r'^packageDeal/$', core_views.packageDeal, name='packageDeal'),
    url(r'^realestate/$', core_views.realestate, name='realestate'),
    url(r'^cart/$', core_views.cart, name='cart'),
    url(r'^msg_send_successfully/$', core_views.msg_send_successfully, name='msg_send_successfully'),
    url(r'^offer_sent_successfully/$', core_views.offer_sent_successfully, name='offer_sent_successfully'),
    url(r'^product_added_successfully.html/$', core_views.product_added_successfully, name='product_added_successfully.html'),
    url(r'^account_activation_sent/$', core_views.account_activation_sent, name='account_activation_sent'),
    url(r'^activate/(?P<uidb64>[0-9A-Za-z_\-]+)/(?P<token>[0-9A-Za-z]{1,13}-[0-9A-Za-z]{1,20})/$',
        core_views.activate, name='activate'),
    url(r'^year=(?P<year>[0-9]+)_type=(?P<type>[0-9]+)/$',core_views.catalog_by_year_type, name='catalog_by_year_type'),
    url(r'^search/$',core_views.search, name='search'),
    url(r'^results/$',core_views.search, name='search'),
    url(r'^advancedSearch/$',core_views.advancedSearch, name='advancedSearch'),
    url(r'^about/$',core_views.about, name='about'),
]

