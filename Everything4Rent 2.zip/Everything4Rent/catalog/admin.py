from .models import *
from django.contrib import admin
from django import forms

class Everything4RentModelForm(forms.ModelForm):
    text = forms.CharField(widget=forms.Textarea(attrs={'rows': 5, 'cols': 100}), required=False)
    class Meta:
        model = Product
        fields = ('__all__')

class Everything4Rent_Admin(admin.ModelAdmin):
    form = Everything4RentModelForm

admin.site.register(Product, Everything4Rent_Admin)
admin.site.register(Category)
admin.site.register(SubCategory)
admin.site.register(HomePage)
admin.site.register(AuthorizedAgent)
admin.site.register(VideoHomePage)
admin.site.register(SellMethod)
admin.site.register(Profile)
admin.site.register(Offer)
